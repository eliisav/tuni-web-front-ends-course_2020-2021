
export { default as diagnoseRouter } from './routes-diagnoses';
export { default as patientRouter } from './routes-patients';

// ** enter commit sha of your repository in here **
export const commitSHA = 'f86e4c3';

